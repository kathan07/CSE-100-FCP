#include<stdio.h>
#include<string.h>
void main(){
    char d[100];
    gets(d);
    int i;
    i = strlen(d);
    printf("Length of string is:%d",i);
}