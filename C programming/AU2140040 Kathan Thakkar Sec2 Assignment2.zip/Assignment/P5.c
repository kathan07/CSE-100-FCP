#include<stdio.h>
#include<stdlib.h>
void main(){
    int n;
    n = rand()%100+1;
    printf("%d",n);
}