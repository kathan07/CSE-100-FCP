#include<stdio.h>
void main(){
    int i,sum;
    sum = 0;
    for ( i = 0; i < 11; i++)
    {
        sum = sum+i;
    }
    printf("%d",sum);
    
}