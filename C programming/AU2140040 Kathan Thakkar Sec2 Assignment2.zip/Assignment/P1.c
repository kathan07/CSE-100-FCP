#include<stdio.h>
void main(){
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    if (n%13 == 0)
    {
        printf("%d is divisible by 13",n);
    }
    else;
    {
        printf("&d is not divisible by 13",n);
    }
    
}