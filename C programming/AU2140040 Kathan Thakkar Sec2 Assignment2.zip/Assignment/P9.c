#include<stdio.h>
void main(){
    float m,f,i;
    scanf("%f",&m);
    i = m*39.3701;
    f = i/12;
    printf("%f",f);
}