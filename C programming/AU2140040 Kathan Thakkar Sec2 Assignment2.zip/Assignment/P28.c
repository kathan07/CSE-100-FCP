#include <stdio.h>
void PrintLine(){
	printf("----------------\n");
}
int main(){
	PrintLine();
	printf("Hello how are you \n");
	PrintLine();
}
