#include <stdio.h>
void Greet(){
	printf("Hello sir how may i help you..\n");
}
int main(){
	Greet();
}
